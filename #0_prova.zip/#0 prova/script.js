document.addEventListener('DOMContentLoaded', function() {
    const menuButton = document.getElementById('menuButton');
    const menuOverlay = document.getElementById('menuOverlay');
    const closeButton = document.getElementById('closeButton');

    if (menuButton && menuOverlay && closeButton) {
        menuButton.addEventListener('click', function() {
            menuOverlay.style.display = 'block';
        });

        closeButton.addEventListener('click', function() {
            menuOverlay.style.display = 'none';
        });

        window.addEventListener('click', function(event) {
            if (event.target === menuOverlay) {
                menuOverlay.style.display = 'none';
            }
        });
    }
});