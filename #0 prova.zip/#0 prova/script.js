// classica interazione javascript per l'interazione con i vari bottoni e l'overlay
//aggiunta di alert post interazione 


document.addEventListener('DOMContentLoaded', function() {
    const menuButton = document.getElementById('menuButton');
    const menuOverlay = document.getElementById('menuOverlay');
    const closeButton = document.getElementById('closeButton');

    if (menuButton && menuOverlay && closeButton) {
        menuButton.addEventListener('click', function() {
            menuOverlay.style.display = 'block';
            menuOverlay.classList.add('active');
            alert('stai cliccando il menù !');
        });

        closeButton.addEventListener('click', function() {
            menuOverlay.style.display = 'none';
            alert('Arrivederci');
        });

        window.addEventListener('click', function(event) {
            if (event.target === menuOverlay) {
                menuOverlay.style.display = 'none';
                
            }
        });
    }

    
});